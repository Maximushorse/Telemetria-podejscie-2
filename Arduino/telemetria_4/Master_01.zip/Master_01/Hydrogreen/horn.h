/**
* @file b
* @brief
* @author
* @date
* @todo
* @bug
* @copyright 2020 HYDROGREEN TEAM
*/
#pragma once

#include <stdint-gcc.h>


extern void safety_step(void);
extern void safety_init(void);

