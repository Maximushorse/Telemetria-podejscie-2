/*
 * lapsd_time.h
 *
 *  Created on: May 14, 2021
 *      Author: Alicja Miekina
 */

#ifndef MEASUREMENTS_H_
#define MEASUREMENTS_H_


#pragma once

#include <stdint-gcc.h>

#endif /* MEASUREMENTS_H_ */



extern void measurements_step(void);
extern void lapsd_time(void);
extern void calcSpeed(void);
extern void softstart(void);

extern uint8_t speedPulses;
extern uint16_t speedPulsesToAverage;
extern float calcInterimSpeed;
extern uint16_t sd_time;
extern uint16_t prevsd_time;
extern uint16_t sd_timeBetweenPulses;
extern uint16_t sd_timeOf;
