/**
* @file sd_timers.c
* @brief Biblioteka sluzaca do zarzadzania czasem systemu
* @author Piotr Durakiewicz
* @date 30.10.2020
* @todo
* @bug
* @copyright 2020 HYDROGREEN TEAM
*/

#include "sd_timers.h"
#include "tim.h"
#include "hydrogreen.h"
#include "measurements.h"

// ******************************************************************************************************************************************************** //

static volatile uint32_t sd_timers_sysCycle100kHzCnt;		///< Licznik tickow zegara nastepujacych z czestotliwoscia 100kHz
volatile uint8_t sd_timers_tick1kHz; 				///< Flaga ustawiana co okres T = 1ms
volatile uint8_t sd_timers_tick10kHz; 				///< Flaga ustawiana co okres T = 0,1ms
volatile uint8_t sd_timers_mainsd_timeHours; 				///< Czas pracy systemu - liczba godzin
volatile uint8_t sd_timers_mainsd_timeMinutes; 			///< Czas pracy systemu - liczba minut
volatile uint8_t sd_timers_mainsd_timeSeconds; 			///< Czas pracy systemu - liczba sekund
volatile uint16_t sd_timers_mainsd_timeMiliseconds; 			///< Czas pracy systemu - liczba milisekund
uint32_t sd_timers_minSysCyclePeriod;				///< Minimalny czas trwania petli hydrogreen_step()
uint32_t sd_timers_maxSysCyclePeriod;				///< Maksymalny czas trwania petli hydrogreen_step()
uint32_t sd_timers_avgSysCyclePeriod;				///< Sredni czas trwania petli hydrogreen_step()
volatile uint8_t lapsd_time_flag;
// ******************************************************************************************************************************************************** //

static inline void sd_timers_step(void);
static inline void setSystemOperatingsd_time(void);
void sd_timers_init(void);
void sd_timers_beforeStep1kHz(void);
void sd_timers_afterStep1kHz(void);

// ******************************************************************************************************************************************************** //

/**
* @fn sd_timers_init(void)
* @brief Funkcja inicjalizujaca sd_timery
*/
void sd_timers_init(void)
{
  HAL_TIM_Base_Start_IT(&htim6);		//Inicjalizuj TIM6 pracujacy z czestotliwoscia 10kHz
  HAL_TIM_Base_Start_IT(&htim7);		//Inicjalizuj TIM7 pracujacy z czestotliwoscia 100kHz
}

/**
* @fn sd_timers_main(void)
* @brief Glowna funkcja odpowiadajaca za interwaly czasowe wykorzystywane w systemie
*/
static inline void sd_timers_step(void)
{
  sd_timers_tick1kHz = 1;

  setSystemOperatingsd_time();

}

/**
* @fn setSystemOperatingsd_time(void)
* @brief Funkcja przeliczajaca czas pracy systemu na milisekundy, sekundy, minuty oraz godziny
*/
static inline void setSystemOperatingsd_time(void)
{
  sd_timers_mainsd_timeMiliseconds++;

  //Sekundy
  if (sd_timers_mainsd_timeMiliseconds >= PERIOD_1S)
    {
      sd_timers_mainsd_timeMiliseconds = 0;
      sd_timers_mainsd_timeSeconds++;
    }

  //Minuty
  if (sd_timers_mainsd_timeSeconds >= 60)
    {
      sd_timers_mainsd_timeSeconds = 0;
      sd_timers_mainsd_timeMinutes++;
    }

  //Godziny
  if (sd_timers_mainsd_timeMinutes >= 60)
    {
      sd_timers_mainsd_timeMinutes = 0;
      sd_timers_mainsd_timeHours++;
    }
}

/**
* @fn sd_timers_beforeStep1kHz(void)
* @brief Funkcja sluzaca do obliczania czasu trwania petli hydrogreen_step(), wywolac przed hydrogreen_step()
*/
void sd_timers_beforeStep1kHz(void)
{
  sd_timers_sysCycle100kHzCnt = 0;
}

/**
* @fn sd_timers_afterStep1kHz(void)
* @brief Funkcja sluzaca do obliczania czasu trwania petli hydrogreen_step(), wywolac po hydrogreen_step()
*/
void sd_timers_afterStep1kHz(void)
{
  static uint8_t initFlag;
  static uint32_t actSysCyclePeriod;
  static uint32_t avgSysCyclePeriodSum;
  static uint16_t avgCnt;

  //Warunek wykorzystywany przy inicjalizacji systemu (tylko raz)
  if (!initFlag)
    {
      sd_timers_minSysCyclePeriod = 10 * sd_timers_sysCycle100kHzCnt;
      initFlag = 1;
    }

  actSysCyclePeriod = 10 * sd_timers_sysCycle100kHzCnt; //Przeliczenie otrzymanej wartosci na mikrosekundy

  sd_timers_sysCycle100kHzCnt = 0;

  //Oblicz sredni czas trwania cyklu ze 100 probek
  if (avgCnt <= 100)
    {
      avgSysCyclePeriodSum = avgSysCyclePeriodSum + actSysCyclePeriod;
      avgCnt++;
    }
  else
    {
      sd_timers_avgSysCyclePeriod =  avgSysCyclePeriodSum / avgCnt;
      avgSysCyclePeriodSum = 0;
      avgCnt = 0;
    }

  //Najkrotszy czas trwania cyklu
  if (actSysCyclePeriod < sd_timers_minSysCyclePeriod)
    {
      sd_timers_minSysCyclePeriod =  actSysCyclePeriod;
    }

  //Najdluzszy czas trwania cyklu
  if (actSysCyclePeriod > sd_timers_maxSysCyclePeriod)
    {
      sd_timers_maxSysCyclePeriod = actSysCyclePeriod;
    }
}

void HAL_SYSTICK_Callback(void)
{
  sd_timers_step();

}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM6)
    {
      sd_timers_tick10kHz = 1;
    }

  if (htim->Instance == TIM7)
    {
      sd_timers_sysCycle100kHzCnt++;
    }
}
