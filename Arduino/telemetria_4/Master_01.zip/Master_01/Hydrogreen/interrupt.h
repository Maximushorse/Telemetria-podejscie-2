/*
 * interrupt.h
 * przerwania od czujnika wodoru i predkosci
 *
 *  Created on: May 14, 2021
 *      Author: Alicja Miekina
 */



#pragma once

#include <stdint-gcc.h>

extern void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);


